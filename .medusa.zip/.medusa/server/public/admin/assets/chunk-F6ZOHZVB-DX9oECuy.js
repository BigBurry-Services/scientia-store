import{j as r}from"./index-1i0k7UWC.js";var e=({children:s})=>r.jsx("span",{className:"sr-only",children:s});export{e as V};
