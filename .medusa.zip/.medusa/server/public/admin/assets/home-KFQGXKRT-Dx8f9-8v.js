import{u as r,r as t,j as s}from"./index-1i0k7UWC.js";var o=()=>{const e=r();return t.useEffect(()=>{e("/orders",{replace:!0})},[e]),s.jsx("div",{})};export{o as Component};
