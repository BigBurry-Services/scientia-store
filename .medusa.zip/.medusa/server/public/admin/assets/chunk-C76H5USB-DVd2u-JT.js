import{au as c}from"./index-1i0k7UWC.js";function m(o,r){const[t]=c(),s={};return o.forEach(a=>{const e=r?`${r}_${a}`:a,u=t.get(e)||void 0;s[a]=u}),s}export{m as u};
