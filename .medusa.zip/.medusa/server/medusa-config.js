"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
(0, utils_1.loadEnv)(process.env.NODE_ENV || 'development', process.cwd());
const requireEnv = (key) => {
    const value = process.env[key];
    if (!value) {
        throw new Error(`Missing required environment variable: ${key}`);
    }
    return value;
};
module.exports = (0, utils_1.defineConfig)({
    projectConfig: {
        databaseUrl: requireEnv("DATABASE_URL"),
        http: {
            storeCors: requireEnv("STORE_CORS"),
            adminCors: requireEnv("ADMIN_CORS"),
            authCors: requireEnv("AUTH_CORS"),
            jwtSecret: requireEnv("JWT_SECRET"),
            cookieSecret: requireEnv("COOKIE_SECRET"),
        }
    },
    modules: [
        {
            resolve: "./src/modules/digital-asset",
        },
    ],
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVkdXNhLWNvbmZpZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL21lZHVzYS1jb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxxREFBaUU7QUFFakUsSUFBQSxlQUFPLEVBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLElBQUksYUFBYSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFBO0FBRTdELE1BQU0sVUFBVSxHQUFHLENBQUMsR0FBVyxFQUFVLEVBQUU7SUFDekMsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQTtJQUU5QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDWCxNQUFNLElBQUksS0FBSyxDQUFDLDBDQUEwQyxHQUFHLEVBQUUsQ0FBQyxDQUFBO0lBQ2xFLENBQUM7SUFFRCxPQUFPLEtBQUssQ0FBQTtBQUNkLENBQUMsQ0FBQTtBQUVELE1BQU0sQ0FBQyxPQUFPLEdBQUcsSUFBQSxvQkFBWSxFQUFDO0lBQzVCLGFBQWEsRUFBRTtRQUNiLFdBQVcsRUFBRSxVQUFVLENBQUMsY0FBYyxDQUFDO1FBQ3ZDLElBQUksRUFBRTtZQUNKLFNBQVMsRUFBRSxVQUFVLENBQUMsWUFBWSxDQUFDO1lBQ25DLFNBQVMsRUFBRSxVQUFVLENBQUMsWUFBWSxDQUFDO1lBQ25DLFFBQVEsRUFBRSxVQUFVLENBQUMsV0FBVyxDQUFDO1lBQ2pDLFNBQVMsRUFBRSxVQUFVLENBQUMsWUFBWSxDQUFDO1lBQ25DLFlBQVksRUFBRSxVQUFVLENBQUMsZUFBZSxDQUFDO1NBQzFDO0tBQ0Y7SUFDRCxPQUFPLEVBQUU7UUFDUDtZQUNFLE9BQU8sRUFBRSw2QkFBNkI7U0FDdkM7S0FDRjtDQUNGLENBQUMsQ0FBQSJ9