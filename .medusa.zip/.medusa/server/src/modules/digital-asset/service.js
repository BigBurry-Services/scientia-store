"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const digital_asset_1 = __importDefault(require("./models/digital-asset"));
const variant_digital_asset_link_1 = __importDefault(require("./models/variant-digital-asset-link"));
class DigitalAssetModuleService extends (0, utils_1.MedusaService)({
    DigitalAsset: digital_asset_1.default,
    VariantDigitalAssetLink: variant_digital_asset_link_1.default,
}) {
    async attachAssetToVariant(input) {
        const existing = await this.listVariantDigitalAssetLinks({
            digital_asset_id: input.digital_asset_id,
            variant_id: input.variant_id,
        });
        if (existing.length) {
            return existing[0];
        }
        const created = await this.createVariantDigitalAssetLinks([input]);
        return created[0];
    }
    async listAssetsForVariantIds(variantIds) {
        if (!variantIds.length) {
            return [];
        }
        const uniqueVariantIds = new Set(variantIds);
        const allLinks = await this.listVariantDigitalAssetLinks({});
        const links = allLinks.filter((link) => uniqueVariantIds.has(link.variant_id));
        if (!links.length) {
            return [];
        }
        const uniqueAssetIds = new Set(links.map((link) => link.digital_asset_id));
        const allAssets = await this.listDigitalAssets({ is_active: true });
        const assets = allAssets.filter((asset) => uniqueAssetIds.has(asset.id));
        const assetMap = new Map(assets.map((asset) => [asset.id, asset]));
        return links
            .map((link) => ({
            variant_id: link.variant_id,
            asset: assetMap.get(link.digital_asset_id),
        }))
            .filter((entry) => !!entry.asset);
    }
}
exports.default = DigitalAssetModuleService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2RpZ2l0YWwtYXNzZXQvc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQUFBLHFEQUF5RDtBQUN6RCwyRUFBaUQ7QUFDakQscUdBQXlFO0FBRXpFLE1BQU0seUJBQTBCLFNBQVEsSUFBQSxxQkFBYSxFQUFDO0lBQ3BELFlBQVksRUFBWix1QkFBWTtJQUNaLHVCQUF1QixFQUF2QixvQ0FBdUI7Q0FDeEIsQ0FBQztJQUNBLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxLQUcxQjtRQUNDLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLDRCQUE0QixDQUN0RDtZQUNFLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxnQkFBZ0I7WUFDeEMsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVO1NBQzdCLENBQ0YsQ0FBQTtRQUVELElBQUksUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3BCLE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFBO1FBQ3BCLENBQUM7UUFFRCxNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUE7UUFFbEUsT0FBTyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDbkIsQ0FBQztJQUVELEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxVQUFvQjtRQUNoRCxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3ZCLE9BQU8sRUFBRSxDQUFBO1FBQ1gsQ0FBQztRQUVELE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUE7UUFDNUMsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsNEJBQTRCLENBQUMsRUFBRSxDQUFDLENBQUE7UUFDNUQsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFBO1FBRTlFLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDbEIsT0FBTyxFQUFFLENBQUE7UUFDWCxDQUFDO1FBRUQsTUFBTSxjQUFjLEdBQUcsSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQTtRQUMxRSxNQUFNLFNBQVMsR0FBRyxNQUFNLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQ25FLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUE7UUFFeEUsTUFBTSxRQUFRLEdBQUcsSUFBSSxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUVsRSxPQUFPLEtBQUs7YUFDVCxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDZCxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7WUFDM0IsS0FBSyxFQUFFLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1NBQzNDLENBQUMsQ0FBQzthQUNGLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUNyQyxDQUFDO0NBQ0Y7QUFFRCxrQkFBZSx5QkFBeUIsQ0FBQSJ9