"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const VariantDigitalAssetLink = utils_1.model.define("variant_digital_asset_link", {
    id: utils_1.model.id().primaryKey(),
    variant_id: utils_1.model.text(),
    digital_asset_id: utils_1.model.text(),
});
exports.default = VariantDigitalAssetLink;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFyaWFudC1kaWdpdGFsLWFzc2V0LWxpbmsuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9kaWdpdGFsLWFzc2V0L21vZGVscy92YXJpYW50LWRpZ2l0YWwtYXNzZXQtbGluay50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHFEQUFpRDtBQUVqRCxNQUFNLHVCQUF1QixHQUFHLGFBQUssQ0FBQyxNQUFNLENBQUMsNEJBQTRCLEVBQUU7SUFDekUsRUFBRSxFQUFFLGFBQUssQ0FBQyxFQUFFLEVBQUUsQ0FBQyxVQUFVLEVBQUU7SUFDM0IsVUFBVSxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUU7SUFDeEIsZ0JBQWdCLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRTtDQUMvQixDQUFDLENBQUE7QUFFRixrQkFBZSx1QkFBdUIsQ0FBQSJ9