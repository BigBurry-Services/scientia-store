"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20260309111635 = void 0;
const migrations_1 = require("@medusajs/framework/mikro-orm/migrations");
class Migration20260309111635 extends migrations_1.Migration {
    async up() {
        this.addSql(`create table if not exists "digital_asset" ("id" text not null, "title" text not null, "file_url" text not null, "file_name" text null, "mime_type" text null, "storage_provider" text not null default 'external', "is_active" boolean not null default true, "created_at" timestamptz not null default now(), "updated_at" timestamptz not null default now(), "deleted_at" timestamptz null, constraint "digital_asset_pkey" primary key ("id"));`);
        this.addSql(`CREATE INDEX IF NOT EXISTS "IDX_digital_asset_deleted_at" ON "digital_asset" ("deleted_at") WHERE deleted_at IS NULL;`);
        this.addSql(`create table if not exists "variant_digital_asset_link" ("id" text not null, "variant_id" text not null, "digital_asset_id" text not null, "created_at" timestamptz not null default now(), "updated_at" timestamptz not null default now(), "deleted_at" timestamptz null, constraint "variant_digital_asset_link_pkey" primary key ("id"));`);
        this.addSql(`CREATE INDEX IF NOT EXISTS "IDX_variant_digital_asset_link_deleted_at" ON "variant_digital_asset_link" ("deleted_at") WHERE deleted_at IS NULL;`);
    }
    async down() {
        this.addSql(`drop table if exists "digital_asset" cascade;`);
        this.addSql(`drop table if exists "variant_digital_asset_link" cascade;`);
    }
}
exports.Migration20260309111635 = Migration20260309111635;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWlncmF0aW9uMjAyNjAzMDkxMTE2MzUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9kaWdpdGFsLWFzc2V0L21pZ3JhdGlvbnMvTWlncmF0aW9uMjAyNjAzMDkxMTE2MzUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEseUVBQXFFO0FBRXJFLE1BQWEsdUJBQXdCLFNBQVEsc0JBQVM7SUFFM0MsS0FBSyxDQUFDLEVBQUU7UUFDZixJQUFJLENBQUMsTUFBTSxDQUFDLHNiQUFzYixDQUFDLENBQUM7UUFDcGMsSUFBSSxDQUFDLE1BQU0sQ0FBQyx1SEFBdUgsQ0FBQyxDQUFDO1FBRXJJLElBQUksQ0FBQyxNQUFNLENBQUMsK1VBQStVLENBQUMsQ0FBQztRQUM3VixJQUFJLENBQUMsTUFBTSxDQUFDLGlKQUFpSixDQUFDLENBQUM7SUFDakssQ0FBQztJQUVRLEtBQUssQ0FBQyxJQUFJO1FBQ2pCLElBQUksQ0FBQyxNQUFNLENBQUMsK0NBQStDLENBQUMsQ0FBQztRQUU3RCxJQUFJLENBQUMsTUFBTSxDQUFDLDREQUE0RCxDQUFDLENBQUM7SUFDNUUsQ0FBQztDQUVGO0FBaEJELDBEQWdCQyJ9