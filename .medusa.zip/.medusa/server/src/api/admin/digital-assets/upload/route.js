"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const digital_asset_1 = require("../../../../modules/digital-asset");
const supabase_storage_1 = require("../../../../lib/supabase-storage");
const readRawBody = async (req, maxBytes = 100 * 1024 * 1024) => {
    const chunks = [];
    let total = 0;
    for await (const chunk of req) {
        const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
        total += buffer.length;
        if (total > maxBytes) {
            throw new Error("File too large. Max supported size is 100MB.");
        }
        chunks.push(buffer);
    }
    return Buffer.concat(chunks);
};
async function POST(req, res) {
    const service = req.scope.resolve(digital_asset_1.DIGITAL_ASSET_MODULE);
    const title = String(req.query.title || "").trim();
    const fileName = String(req.query.file_name || "").trim();
    const mimeType = String(req.query.mime_type || "").trim();
    if (!title) {
        return res.status(400).json({
            message: "`title` is required.",
        });
    }
    if (!fileName) {
        return res.status(400).json({
            message: "`file_name` is required.",
        });
    }
    let fileBuffer;
    try {
        fileBuffer = await readRawBody(req);
    }
    catch (e) {
        return res.status(400).json({
            message: e instanceof Error ? e.message : "Failed to read uploaded file body.",
        });
    }
    if (!fileBuffer.length) {
        return res.status(400).json({
            message: "Uploaded file is empty.",
        });
    }
    try {
        const { publicUrl } = await (0, supabase_storage_1.uploadToSupabaseStorage)({
            fileBuffer,
            fileName,
            mimeType,
        });
        const [asset] = await service.createDigitalAssets([
            {
                title,
                file_url: publicUrl,
                file_name: fileName,
                mime_type: mimeType || null,
                storage_provider: "supabase",
                is_active: true,
            },
        ]);
        return res.status(201).json({
            digital_asset: asset,
        });
    }
    catch (e) {
        return res.status(500).json({
            message: e instanceof Error
                ? e.message
                : "Failed to upload file and create digital asset.",
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2RpZ2l0YWwtYXNzZXRzL3VwbG9hZC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQTBCQSxvQkFtRUM7QUE1RkQscUVBQXdFO0FBRXhFLHVFQUEwRTtBQUUxRSxNQUFNLFdBQVcsR0FBRyxLQUFLLEVBQ3ZCLEdBQWtCLEVBQ2xCLFFBQVEsR0FBRyxHQUFHLEdBQUcsSUFBSSxHQUFHLElBQUksRUFDNUIsRUFBRTtJQUNGLE1BQU0sTUFBTSxHQUFhLEVBQUUsQ0FBQTtJQUMzQixJQUFJLEtBQUssR0FBRyxDQUFDLENBQUE7SUFFYixJQUFJLEtBQUssRUFBRSxNQUFNLEtBQUssSUFBSSxHQUFVLEVBQUUsQ0FBQztRQUNyQyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUE7UUFDbEUsS0FBSyxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUE7UUFFdEIsSUFBSSxLQUFLLEdBQUcsUUFBUSxFQUFFLENBQUM7WUFDckIsTUFBTSxJQUFJLEtBQUssQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFBO1FBQ2pFLENBQUM7UUFFRCxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ3JCLENBQUM7SUFFRCxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDOUIsQ0FBQyxDQUFBO0FBRU0sS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQ2hFLE1BQU0sT0FBTyxHQUE4QixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FDMUQsb0NBQW9CLENBQ3JCLENBQUE7SUFFRCxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUE7SUFDbEQsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFBO0lBQ3pELE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtJQUV6RCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDWCxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxzQkFBc0I7U0FDaEMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNkLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLDBCQUEwQjtTQUNwQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsSUFBSSxVQUFrQixDQUFBO0lBRXRCLElBQUksQ0FBQztRQUNILFVBQVUsR0FBRyxNQUFNLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQTtJQUNyQyxDQUFDO0lBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztRQUNYLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUNMLENBQUMsWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLG9DQUFvQztTQUN4RSxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUN2QixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSx5QkFBeUI7U0FDbkMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELElBQUksQ0FBQztRQUNILE1BQU0sRUFBRSxTQUFTLEVBQUUsR0FBRyxNQUFNLElBQUEsMENBQXVCLEVBQUM7WUFDbEQsVUFBVTtZQUNWLFFBQVE7WUFDUixRQUFRO1NBQ1QsQ0FBQyxDQUFBO1FBRUYsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLG1CQUFtQixDQUFDO1lBQ2hEO2dCQUNFLEtBQUs7Z0JBQ0wsUUFBUSxFQUFFLFNBQVM7Z0JBQ25CLFNBQVMsRUFBRSxRQUFRO2dCQUNuQixTQUFTLEVBQUUsUUFBUSxJQUFJLElBQUk7Z0JBQzNCLGdCQUFnQixFQUFFLFVBQVU7Z0JBQzVCLFNBQVMsRUFBRSxJQUFJO2FBQ2hCO1NBQ0YsQ0FBQyxDQUFBO1FBRUYsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixhQUFhLEVBQUUsS0FBSztTQUNyQixDQUFDLENBQUE7SUFDSixDQUFDO0lBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztRQUNYLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUNMLENBQUMsWUFBWSxLQUFLO2dCQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87Z0JBQ1gsQ0FBQyxDQUFDLGlEQUFpRDtTQUN4RCxDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQyJ9