"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const digital_asset_1 = require("../../../../modules/digital-asset");
async function GET(req, res) {
    const service = req.scope.resolve(digital_asset_1.DIGITAL_ASSET_MODULE);
    const { id } = req.params;
    const asset = await service.retrieveDigitalAsset(id).catch(() => null);
    if (!asset) {
        return res.status(404).json({
            message: "Digital asset not found.",
        });
    }
    const links = await service.listVariantDigitalAssetLinks({
        digital_asset_id: id,
    });
    res.status(200).json({
        digital_asset: asset,
        variant_links: links,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2RpZ2l0YWwtYXNzZXRzL1tpZF0vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFJQSxrQkF1QkM7QUExQkQscUVBQXdFO0FBR2pFLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLE9BQU8sR0FBOEIsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQzFELG9DQUFvQixDQUNyQixDQUFBO0lBRUQsTUFBTSxFQUFFLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFFekIsTUFBTSxLQUFLLEdBQUcsTUFBTSxPQUFPLENBQUMsb0JBQW9CLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFBO0lBRXRFLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNYLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLDBCQUEwQjtTQUNwQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsTUFBTSxLQUFLLEdBQUcsTUFBTSxPQUFPLENBQUMsNEJBQTRCLENBQUM7UUFDdkQsZ0JBQWdCLEVBQUUsRUFBRTtLQUNyQixDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUNuQixhQUFhLEVBQUUsS0FBSztRQUNwQixhQUFhLEVBQUUsS0FBSztLQUNyQixDQUFDLENBQUE7QUFDSixDQUFDIn0=