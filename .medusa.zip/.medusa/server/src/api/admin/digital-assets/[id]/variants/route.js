"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const utils_1 = require("@medusajs/framework/utils");
const digital_asset_1 = require("../../../../../modules/digital-asset");
async function POST(req, res) {
    const service = req.scope.resolve(digital_asset_1.DIGITAL_ASSET_MODULE);
    const productModuleService = req.scope.resolve(utils_1.Modules.PRODUCT);
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { id } = req.params;
    const { variant_id } = req.body;
    if (!variant_id) {
        return res.status(400).json({
            message: "`variant_id` is required.",
        });
    }
    const asset = await service.retrieveDigitalAsset(id).catch(() => null);
    if (!asset) {
        return res.status(404).json({
            message: "Digital asset not found.",
        });
    }
    // Validate that the variant exists in the product module.
    const variant = await productModuleService
        .retrieveProductVariant(variant_id)
        .catch(() => null);
    if (!variant) {
        return res.status(404).json({
            message: "Product variant not found.",
        });
    }
    const link = await service.attachAssetToVariant({
        digital_asset_id: id,
        variant_id,
    });
    const { data: products } = await query.graph({
        entity: "product",
        fields: ["id", "title", "variants.id", "variants.title"],
        filters: {
            variants: {
                id: variant_id,
            },
        },
    });
    res.status(200).json({
        variant_link: link,
        variant: {
            id: variant.id,
            title: variant.title,
        },
        product: products?.[0] ?? null,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2RpZ2l0YWwtYXNzZXRzL1tpZF0vdmFyaWFudHMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFZQSxvQkE2REM7QUF4RUQscURBR2tDO0FBQ2xDLHdFQUEyRTtBQU9wRSxLQUFLLFVBQVUsSUFBSSxDQUN4QixHQUFxQyxFQUNyQyxHQUFtQjtJQUVuQixNQUFNLE9BQU8sR0FBOEIsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQzFELG9DQUFvQixDQUNyQixDQUFBO0lBQ0QsTUFBTSxvQkFBb0IsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDL0QsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFFaEUsTUFBTSxFQUFFLEVBQUUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUE7SUFDekIsTUFBTSxFQUFFLFVBQVUsRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFL0IsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2hCLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLDJCQUEyQjtTQUNyQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsTUFBTSxLQUFLLEdBQUcsTUFBTSxPQUFPLENBQUMsb0JBQW9CLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFBO0lBRXRFLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNYLE9BQU8sR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsT0FBTyxFQUFFLDBCQUEwQjtTQUNwQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsMERBQTBEO0lBQzFELE1BQU0sT0FBTyxHQUFHLE1BQU0sb0JBQW9CO1NBQ3ZDLHNCQUFzQixDQUFDLFVBQVUsQ0FBQztTQUNsQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUE7SUFFcEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2IsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsNEJBQTRCO1NBQ3RDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxNQUFNLElBQUksR0FBRyxNQUFNLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQztRQUM5QyxnQkFBZ0IsRUFBRSxFQUFFO1FBQ3BCLFVBQVU7S0FDWCxDQUFDLENBQUE7SUFFRixNQUFNLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztRQUMzQyxNQUFNLEVBQUUsU0FBUztRQUNqQixNQUFNLEVBQUUsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLGFBQWEsRUFBRSxnQkFBZ0IsQ0FBQztRQUN4RCxPQUFPLEVBQUU7WUFDUCxRQUFRLEVBQUU7Z0JBQ1IsRUFBRSxFQUFFLFVBQVU7YUFDZjtTQUNGO0tBQ0YsQ0FBQyxDQUFBO0lBRUYsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDbkIsWUFBWSxFQUFFLElBQUk7UUFDbEIsT0FBTyxFQUFFO1lBQ1AsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFFO1lBQ2QsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO1NBQ3JCO1FBQ0QsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUk7S0FDL0IsQ0FBQyxDQUFBO0FBQ0osQ0FBQyJ9