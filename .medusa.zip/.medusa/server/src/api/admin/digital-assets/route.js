"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
exports.POST = POST;
const digital_asset_1 = require("../../../modules/digital-asset");
async function GET(req, res) {
    const service = req.scope.resolve(digital_asset_1.DIGITAL_ASSET_MODULE);
    const assets = await service.listDigitalAssets({}, { order: { created_at: "DESC" } });
    res.status(200).json({
        digital_assets: assets,
    });
}
async function POST(req, res) {
    const service = req.scope.resolve(digital_asset_1.DIGITAL_ASSET_MODULE);
    const { title, file_url, file_name, mime_type, storage_provider, is_active } = req.body;
    if (!title || !file_url) {
        return res.status(400).json({
            message: "`title` and `file_url` are required.",
        });
    }
    const [asset] = await service.createDigitalAssets([
        {
            title,
            file_url,
            file_name: file_name ?? null,
            mime_type: mime_type ?? null,
            storage_provider: storage_provider ?? "external",
            is_active: is_active ?? true,
        },
    ]);
    res.status(201).json({
        digital_asset: asset,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2RpZ2l0YWwtYXNzZXRzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBYUEsa0JBVUM7QUFFRCxvQkErQkM7QUF2REQsa0VBQXFFO0FBWTlELEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLE9BQU8sR0FBOEIsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQzFELG9DQUFvQixDQUNyQixDQUFBO0lBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxPQUFPLENBQUMsaUJBQWlCLENBQUMsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQTtJQUVyRixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUNuQixjQUFjLEVBQUUsTUFBTTtLQUN2QixDQUFDLENBQUE7QUFDSixDQUFDO0FBRU0sS0FBSyxVQUFVLElBQUksQ0FDeEIsR0FBMEMsRUFDMUMsR0FBbUI7SUFFbkIsTUFBTSxPQUFPLEdBQThCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUMxRCxvQ0FBb0IsQ0FDckIsQ0FBQTtJQUVELE1BQU0sRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLEdBQzFFLEdBQUcsQ0FBQyxJQUFJLENBQUE7SUFFVixJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDeEIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsc0NBQXNDO1NBQ2hELENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsbUJBQW1CLENBQUM7UUFDaEQ7WUFDRSxLQUFLO1lBQ0wsUUFBUTtZQUNSLFNBQVMsRUFBRSxTQUFTLElBQUksSUFBSTtZQUM1QixTQUFTLEVBQUUsU0FBUyxJQUFJLElBQUk7WUFDNUIsZ0JBQWdCLEVBQUUsZ0JBQWdCLElBQUksVUFBVTtZQUNoRCxTQUFTLEVBQUUsU0FBUyxJQUFJLElBQUk7U0FDN0I7S0FDRixDQUFDLENBQUE7SUFFRixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUNuQixhQUFhLEVBQUUsS0FBSztLQUNyQixDQUFDLENBQUE7QUFDSixDQUFDIn0=