"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPurchasedLineItems = exports.isOrderPaid = void 0;
const utils_1 = require("@medusajs/framework/utils");
const PAID_STATUSES = new Set([
    "captured",
    "partially_captured",
    "authorized",
    "partially_authorized",
]);
const isOrderPaid = (status) => {
    if (!status) {
        return false;
    }
    return PAID_STATUSES.has(status);
};
exports.isOrderPaid = isOrderPaid;
const isPaidByTransaction = (transactions) => {
    if (!transactions?.length) {
        return false;
    }
    return transactions.some((txn) => ["capture", "authorize"].includes((txn.reference || "").toLowerCase()));
};
const getPurchasedLineItems = async (scope, customerId) => {
    const query = scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const { data: orders } = await query.graph({
        entity: "order",
        fields: [
            "id",
            "customer_id",
            "payment_status",
            "transactions.reference",
            "items.id",
            "items.title",
            "items.variant_id",
        ],
        filters: {
            customer_id: customerId,
        },
    });
    const lineItems = [];
    for (const order of (orders || [])) {
        const orderIsPaid = (0, exports.isOrderPaid)(order.payment_status) || isPaidByTransaction(order.transactions);
        if (!orderIsPaid) {
            continue;
        }
        for (const item of order.items || []) {
            lineItems.push({
                order_id: order.id,
                payment_status: order.payment_status ?? null,
                line_item_id: item.id,
                line_item_title: item.title ?? null,
                variant_id: item.variant_id ?? null,
            });
        }
    }
    return lineItems;
};
exports.getPurchasedLineItems = getPurchasedLineItems;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGVscGVycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvc3RvcmUvZGlnaXRhbC1hc3NldHMvaGVscGVycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxREFBcUU7QUF5QnJFLE1BQU0sYUFBYSxHQUFHLElBQUksR0FBRyxDQUFDO0lBQzVCLFVBQVU7SUFDVixvQkFBb0I7SUFDcEIsWUFBWTtJQUNaLHNCQUFzQjtDQUN2QixDQUFDLENBQUE7QUFFSyxNQUFNLFdBQVcsR0FBRyxDQUFDLE1BQXNCLEVBQUUsRUFBRTtJQUNwRCxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDWixPQUFPLEtBQUssQ0FBQTtJQUNkLENBQUM7SUFFRCxPQUFPLGFBQWEsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDbEMsQ0FBQyxDQUFBO0FBTlksUUFBQSxXQUFXLGVBTXZCO0FBRUQsTUFBTSxtQkFBbUIsR0FBRyxDQUFDLFlBQWlDLEVBQUUsRUFBRTtJQUNoRSxJQUFJLENBQUMsWUFBWSxFQUFFLE1BQU0sRUFBRSxDQUFDO1FBQzFCLE9BQU8sS0FBSyxDQUFBO0lBQ2QsQ0FBQztJQUVELE9BQU8sWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQy9CLENBQUMsU0FBUyxFQUFFLFdBQVcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FDdkUsQ0FBQTtBQUNILENBQUMsQ0FBQTtBQUVNLE1BQU0scUJBQXFCLEdBQUcsS0FBSyxFQUN4QyxLQUF3QyxFQUN4QyxVQUFrQixFQUNZLEVBQUU7SUFDaEMsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUM1RCxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQztRQUN6QyxNQUFNLEVBQUUsT0FBTztRQUNmLE1BQU0sRUFBRTtZQUNOLElBQUk7WUFDSixhQUFhO1lBQ2IsZ0JBQWdCO1lBQ2hCLHdCQUF3QjtZQUN4QixVQUFVO1lBQ1YsYUFBYTtZQUNiLGtCQUFrQjtTQUNuQjtRQUNELE9BQU8sRUFBRTtZQUNQLFdBQVcsRUFBRSxVQUFVO1NBQ3hCO0tBQ0YsQ0FBQyxDQUFBO0lBRUYsTUFBTSxTQUFTLEdBQXdCLEVBQUUsQ0FBQTtJQUV6QyxLQUFLLE1BQU0sS0FBSyxJQUFJLENBQUMsTUFBTSxJQUFJLEVBQUUsQ0FBcUIsRUFBRSxDQUFDO1FBQ3ZELE1BQU0sV0FBVyxHQUNmLElBQUEsbUJBQVcsRUFBQyxLQUFLLENBQUMsY0FBYyxDQUFDLElBQUksbUJBQW1CLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBRTlFLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNqQixTQUFRO1FBQ1YsQ0FBQztRQUVELEtBQUssTUFBTSxJQUFJLElBQUksS0FBSyxDQUFDLEtBQUssSUFBSSxFQUFFLEVBQUUsQ0FBQztZQUNyQyxTQUFTLENBQUMsSUFBSSxDQUFDO2dCQUNiLFFBQVEsRUFBRSxLQUFLLENBQUMsRUFBRTtnQkFDbEIsY0FBYyxFQUFFLEtBQUssQ0FBQyxjQUFjLElBQUksSUFBSTtnQkFDNUMsWUFBWSxFQUFFLElBQUksQ0FBQyxFQUFFO2dCQUNyQixlQUFlLEVBQUUsSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJO2dCQUNuQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJO2FBQ3BDLENBQUMsQ0FBQTtRQUNKLENBQUM7SUFDSCxDQUFDO0lBRUQsT0FBTyxTQUFTLENBQUE7QUFDbEIsQ0FBQyxDQUFBO0FBM0NZLFFBQUEscUJBQXFCLHlCQTJDakMifQ==