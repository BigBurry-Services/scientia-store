"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const digital_asset_1 = require("../../../../../modules/digital-asset");
const helpers_1 = require("../../helpers");
async function GET(req, res) {
    const customerId = req.auth_context?.actor_id;
    if (!customerId) {
        return res.status(401).json({
            message: "You must be logged in as a customer.",
        });
    }
    const service = req.scope.resolve(digital_asset_1.DIGITAL_ASSET_MODULE);
    const { id } = req.params;
    const asset = await service.retrieveDigitalAsset(id).catch(() => null);
    if (!asset || !asset.is_active) {
        return res.status(404).json({
            message: "Digital asset not found.",
        });
    }
    const links = await service.listVariantDigitalAssetLinks({
        digital_asset_id: id,
    });
    const allowedVariantIds = new Set(links.map((link) => link.variant_id));
    if (!allowedVariantIds.size) {
        return res.status(403).json({
            message: "This asset is not attached to any purchasable variant.",
        });
    }
    const purchasedLineItems = await (0, helpers_1.getPurchasedLineItems)(req.scope, customerId);
    const hasPurchasedAsset = purchasedLineItems.some((item) => item.variant_id && allowedVariantIds.has(item.variant_id));
    if (!hasPurchasedAsset) {
        return res.status(403).json({
            message: "You are not entitled to download this asset.",
        });
    }
    const shouldDownload = String(req.query?.download || "") === "1";
    if (shouldDownload) {
        const remoteRes = await fetch(asset.file_url);
        if (!remoteRes.ok) {
            return res.status(502).json({
                message: "Failed to fetch asset from storage provider.",
            });
        }
        const buffer = Buffer.from(await remoteRes.arrayBuffer());
        const fallbackName = `${asset.id}.bin`;
        const fileName = (asset.file_name || fallbackName).replace(/"/g, "");
        const contentType = asset.mime_type ||
            remoteRes.headers.get("content-type") ||
            "application/octet-stream";
        res.setHeader("content-type", contentType);
        res.setHeader("content-length", String(buffer.length));
        res.setHeader("content-disposition", `attachment; filename="${fileName}"`);
        return res.status(200).send(buffer);
    }
    res.status(200).json({
        digital_asset_id: asset.id,
        file_url: asset.file_url,
        file_name: asset.file_name,
        mime_type: asset.mime_type,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2RpZ2l0YWwtYXNzZXRzL1tpZF0vZG93bmxvYWQtdXJsL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBS0Esa0JBNEVDO0FBaEZELHdFQUEyRTtBQUUzRSwyQ0FBcUQ7QUFFOUMsS0FBSyxVQUFVLEdBQUcsQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQy9ELE1BQU0sVUFBVSxHQUFJLEdBQVcsQ0FBQyxZQUFZLEVBQUUsUUFBUSxDQUFBO0lBRXRELElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNoQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxzQ0FBc0M7U0FDaEQsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELE1BQU0sT0FBTyxHQUE4QixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FDMUQsb0NBQW9CLENBQ3JCLENBQUE7SUFDRCxNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQTtJQUV6QixNQUFNLEtBQUssR0FBRyxNQUFNLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUE7SUFFdEUsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUMvQixPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLE9BQU8sRUFBRSwwQkFBMEI7U0FDcEMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELE1BQU0sS0FBSyxHQUFHLE1BQU0sT0FBTyxDQUFDLDRCQUE0QixDQUFDO1FBQ3ZELGdCQUFnQixFQUFFLEVBQUU7S0FDckIsQ0FBQyxDQUFBO0lBQ0YsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQTtJQUV2RSxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDNUIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsd0RBQXdEO1NBQ2xFLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxNQUFNLGtCQUFrQixHQUFHLE1BQU0sSUFBQSwrQkFBcUIsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxDQUFBO0lBQzdFLE1BQU0saUJBQWlCLEdBQUcsa0JBQWtCLENBQUMsSUFBSSxDQUMvQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUNwRSxDQUFBO0lBRUQsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDdkIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsOENBQThDO1NBQ3hELENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxNQUFNLGNBQWMsR0FBRyxNQUFNLENBQUUsR0FBRyxDQUFDLEtBQWEsRUFBRSxRQUFRLElBQUksRUFBRSxDQUFDLEtBQUssR0FBRyxDQUFBO0lBRXpFLElBQUksY0FBYyxFQUFFLENBQUM7UUFDbkIsTUFBTSxTQUFTLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFBO1FBRTdDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDbEIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDMUIsT0FBTyxFQUFFLDhDQUE4QzthQUN4RCxDQUFDLENBQUE7UUFDSixDQUFDO1FBRUQsTUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFBO1FBQ3pELE1BQU0sWUFBWSxHQUFHLEdBQUcsS0FBSyxDQUFDLEVBQUUsTUFBTSxDQUFBO1FBQ3RDLE1BQU0sUUFBUSxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFBO1FBQ3BFLE1BQU0sV0FBVyxHQUNmLEtBQUssQ0FBQyxTQUFTO1lBQ2YsU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO1lBQ3JDLDBCQUEwQixDQUFBO1FBRTVCLEdBQUcsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLFdBQVcsQ0FBQyxDQUFBO1FBQzFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFBO1FBQ3RELEdBQUcsQ0FBQyxTQUFTLENBQUMscUJBQXFCLEVBQUUseUJBQXlCLFFBQVEsR0FBRyxDQUFDLENBQUE7UUFFMUUsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNyQyxDQUFDO0lBRUQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDbkIsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLEVBQUU7UUFDMUIsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRO1FBQ3hCLFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUztRQUMxQixTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7S0FDM0IsQ0FBQyxDQUFBO0FBQ0osQ0FBQyJ9