"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const digital_asset_1 = require("../../../../modules/digital-asset");
const helpers_1 = require("../helpers");
async function GET(req, res) {
    const customerId = req.auth_context?.actor_id;
    if (!customerId) {
        return res.status(401).json({
            message: "You must be logged in as a customer.",
        });
    }
    const service = req.scope.resolve(digital_asset_1.DIGITAL_ASSET_MODULE);
    const purchasedLineItems = await (0, helpers_1.getPurchasedLineItems)(req.scope, customerId);
    const purchasedVariantIds = purchasedLineItems
        .map((item) => item.variant_id)
        .filter((id) => !!id);
    if (!purchasedVariantIds.length) {
        return res.status(200).json({
            downloads: [],
        });
    }
    const variantAssetPairs = await service.listAssetsForVariantIds(purchasedVariantIds);
    const assetByVariantId = new Map(variantAssetPairs.map((entry) => [entry.variant_id, entry.asset]));
    const downloads = purchasedLineItems
        .map((item) => {
        const asset = item.variant_id
            ? assetByVariantId.get(item.variant_id) || null
            : null;
        if (!asset) {
            return null;
        }
        return {
            order_id: item.order_id,
            line_item_id: item.line_item_id,
            line_item_title: item.line_item_title,
            variant_id: item.variant_id,
            digital_asset: {
                id: asset.id,
                title: asset.title,
                file_name: asset.file_name,
                mime_type: asset.mime_type,
            },
        };
    })
        .filter(Boolean);
    res.status(200).json({
        downloads,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL3N0b3JlL2RpZ2l0YWwtYXNzZXRzL215LWRvd25sb2Fkcy9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUtBLGtCQTJEQztBQS9ERCxxRUFBd0U7QUFFeEUsd0NBQWtEO0FBRTNDLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLFVBQVUsR0FBSSxHQUFXLENBQUMsWUFBWSxFQUFFLFFBQVEsQ0FBQTtJQUV0RCxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDaEIsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUMxQixPQUFPLEVBQUUsc0NBQXNDO1NBQ2hELENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCxNQUFNLE9BQU8sR0FBOEIsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQzFELG9DQUFvQixDQUNyQixDQUFBO0lBRUQsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLElBQUEsK0JBQXFCLEVBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsQ0FBQTtJQUM3RSxNQUFNLG1CQUFtQixHQUFHLGtCQUFrQjtTQUMzQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7U0FDOUIsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFnQixFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBRXJDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNoQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzFCLFNBQVMsRUFBRSxFQUFFO1NBQ2QsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELE1BQU0saUJBQWlCLEdBQUcsTUFBTSxPQUFPLENBQUMsdUJBQXVCLENBQzdELG1CQUFtQixDQUNwQixDQUFBO0lBQ0QsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLEdBQUcsQ0FDOUIsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQ2xFLENBQUE7SUFFRCxNQUFNLFNBQVMsR0FBRyxrQkFBa0I7U0FDakMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUU7UUFDWixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVTtZQUMzQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxJQUFJO1lBQy9DLENBQUMsQ0FBQyxJQUFJLENBQUE7UUFFUixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDWCxPQUFPLElBQUksQ0FBQTtRQUNiLENBQUM7UUFFRCxPQUFPO1lBQ0wsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO1lBQ3ZCLFlBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtZQUMvQixlQUFlLEVBQUUsSUFBSSxDQUFDLGVBQWU7WUFDckMsVUFBVSxFQUFFLElBQUksQ0FBQyxVQUFVO1lBQzNCLGFBQWEsRUFBRTtnQkFDYixFQUFFLEVBQUUsS0FBSyxDQUFDLEVBQUU7Z0JBQ1osS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLO2dCQUNsQixTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVM7Z0JBQzFCLFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUzthQUMzQjtTQUNGLENBQUE7SUFDSCxDQUFDLENBQUM7U0FDRCxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUE7SUFFbEIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDbkIsU0FBUztLQUNWLENBQUMsQ0FBQTtBQUNKLENBQUMifQ==