"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = configureStore;
const utils_1 = require("@medusajs/framework/utils");
const core_flows_1 = require("@medusajs/medusa/core-flows");
async function configureStore({ container }) {
    const logger = container.resolve(utils_1.ContainerRegistrationKeys.LOGGER);
    const regionModuleService = container.resolve(utils_1.Modules.REGION);
    logger.info("Adding India region...");
    const existingRegions = await regionModuleService.listRegions({ name: "India" });
    if (existingRegions.length === 0) {
        const { result: regionResult } = await (0, core_flows_1.createRegionsWorkflow)(container).run({
            input: {
                regions: [
                    {
                        name: "India",
                        currency_code: "inr",
                        countries: ["in"],
                        payment_providers: ["pp_system_default"],
                    },
                ],
            },
        });
        const region = regionResult[0];
        await (0, core_flows_1.createTaxRegionsWorkflow)(container).run({
            input: [{
                    country_code: "in",
                    provider_id: "tp_system",
                }],
        });
        logger.info("India region added successfully.");
    }
    else {
        logger.info("India region already exists.");
    }
    logger.info("Creating Scientia catalog categories...");
    const categories = [
        { name: "Books", is_active: true },
        { name: "Physical Books", is_active: true },
        { name: "Question Banks", is_active: true },
        { name: "Notes", is_active: true },
        { name: "Digital Downloads", is_active: true },
    ];
    for (const category of categories) {
        try {
            await (0, core_flows_1.createProductCategoriesWorkflow)(container).run({
                input: {
                    product_categories: [category],
                },
            });
            logger.info(`Category created: ${category.name}`);
        }
        catch (error) {
            const message = error?.message || String(error);
            if (message.includes("already exists")) {
                logger.info(`Category already exists: ${category.name}`);
                continue;
            }
            throw error;
        }
    }
    logger.info("Scientia catalog categories are configured.");
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlndXJlLXN0b3JlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NjcmlwdHMvY29uZmlndXJlLXN0b3JlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBUUEsaUNBaUVDO0FBeEVELHFEQUErRTtBQUMvRSw0REFJcUM7QUFFdEIsS0FBSyxVQUFVLGNBQWMsQ0FBQyxFQUFFLFNBQVMsRUFBWTtJQUNoRSxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGlDQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ25FLE1BQU0sbUJBQW1CLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7SUFFOUQsTUFBTSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBRXRDLE1BQU0sZUFBZSxHQUFHLE1BQU0sbUJBQW1CLENBQUMsV0FBVyxDQUFDLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7SUFFakYsSUFBSSxlQUFlLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1FBQy9CLE1BQU0sRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLEdBQUcsTUFBTSxJQUFBLGtDQUFxQixFQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztZQUN4RSxLQUFLLEVBQUU7Z0JBQ0gsT0FBTyxFQUFFO29CQUNMO3dCQUNJLElBQUksRUFBRSxPQUFPO3dCQUNiLGFBQWEsRUFBRSxLQUFLO3dCQUNwQixTQUFTLEVBQUUsQ0FBQyxJQUFJLENBQUM7d0JBQ2pCLGlCQUFpQixFQUFFLENBQUMsbUJBQW1CLENBQUM7cUJBQzNDO2lCQUNKO2FBQ0o7U0FDSixDQUFDLENBQUM7UUFFSCxNQUFNLE1BQU0sR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFL0IsTUFBTSxJQUFBLHFDQUF3QixFQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztZQUMxQyxLQUFLLEVBQUUsQ0FBQztvQkFDSixZQUFZLEVBQUUsSUFBSTtvQkFDbEIsV0FBVyxFQUFFLFdBQVc7aUJBQzNCLENBQUM7U0FDTCxDQUFDLENBQUM7UUFFSCxNQUFNLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxDQUFDLENBQUM7SUFDcEQsQ0FBQztTQUFNLENBQUM7UUFDSixNQUFNLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUM7SUFDaEQsQ0FBQztJQUVELE1BQU0sQ0FBQyxJQUFJLENBQUMseUNBQXlDLENBQUMsQ0FBQztJQUV2RCxNQUFNLFVBQVUsR0FBRztRQUNmLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFO1FBQ2xDLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUU7UUFDM0MsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRTtRQUMzQyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRTtRQUNsQyxFQUFFLElBQUksRUFBRSxtQkFBbUIsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFO0tBQ2pELENBQUM7SUFFRixLQUFLLE1BQU0sUUFBUSxJQUFJLFVBQVUsRUFBRSxDQUFDO1FBQ2hDLElBQUksQ0FBQztZQUNELE1BQU0sSUFBQSw0Q0FBK0IsRUFBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUM7Z0JBQ2pELEtBQUssRUFBRTtvQkFDSCxrQkFBa0IsRUFBRSxDQUFDLFFBQVEsQ0FBQztpQkFDakM7YUFDSixDQUFDLENBQUM7WUFDSCxNQUFNLENBQUMsSUFBSSxDQUFDLHFCQUFxQixRQUFRLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUN0RCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNiLE1BQU0sT0FBTyxHQUFJLEtBQThCLEVBQUUsT0FBTyxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMxRSxJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDO2dCQUNyQyxNQUFNLENBQUMsSUFBSSxDQUFDLDRCQUE0QixRQUFRLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDekQsU0FBUztZQUNiLENBQUM7WUFDRCxNQUFNLEtBQUssQ0FBQztRQUNoQixDQUFDO0lBQ0wsQ0FBQztJQUVELE1BQU0sQ0FBQyxJQUFJLENBQUMsNkNBQTZDLENBQUMsQ0FBQztBQUMvRCxDQUFDIn0=