"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = createDigitalAsset;
const digital_asset_1 = require("../modules/digital-asset");
async function createDigitalAsset({ container, args }) {
    const logger = container.resolve("logger");
    const service = container.resolve(digital_asset_1.DIGITAL_ASSET_MODULE);
    const title = args?.[0];
    const fileUrl = args?.[1];
    const variantId = args?.[2];
    if (!title || !fileUrl) {
        logger.error("Usage: npx medusa exec ./src/scripts/create-digital-asset.ts <title> <file_url> [variant_id]");
        return;
    }
    const [asset] = await service.createDigitalAssets([
        {
            title,
            file_url: fileUrl,
            storage_provider: "external",
            is_active: true,
        },
    ]);
    logger.info(`Created digital asset: ${asset.id} (${asset.title})`);
    if (variantId) {
        const link = await service.attachAssetToVariant({
            digital_asset_id: asset.id,
            variant_id: variantId,
        });
        logger.info(`Attached asset ${asset.id} to variant ${variantId}. Link: ${link.id}`);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLWRpZ2l0YWwtYXNzZXQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvc2NyaXB0cy9jcmVhdGUtZGlnaXRhbC1hc3NldC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUlBLHFDQXFDQztBQXhDRCw0REFBK0Q7QUFHaEQsS0FBSyxVQUFVLGtCQUFrQixDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBWTtJQUM1RSxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQzFDLE1BQU0sT0FBTyxHQUE4QixTQUFTLENBQUMsT0FBTyxDQUMxRCxvQ0FBb0IsQ0FDckIsQ0FBQTtJQUVELE1BQU0sS0FBSyxHQUFHLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ3ZCLE1BQU0sT0FBTyxHQUFHLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ3pCLE1BQU0sU0FBUyxHQUFHLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBRTNCLElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUN2QixNQUFNLENBQUMsS0FBSyxDQUNWLDhGQUE4RixDQUMvRixDQUFBO1FBQ0QsT0FBTTtJQUNSLENBQUM7SUFFRCxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUMsbUJBQW1CLENBQUM7UUFDaEQ7WUFDRSxLQUFLO1lBQ0wsUUFBUSxFQUFFLE9BQU87WUFDakIsZ0JBQWdCLEVBQUUsVUFBVTtZQUM1QixTQUFTLEVBQUUsSUFBSTtTQUNoQjtLQUNGLENBQUMsQ0FBQTtJQUVGLE1BQU0sQ0FBQyxJQUFJLENBQUMsMEJBQTBCLEtBQUssQ0FBQyxFQUFFLEtBQUssS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUE7SUFFbEUsSUFBSSxTQUFTLEVBQUUsQ0FBQztRQUNkLE1BQU0sSUFBSSxHQUFHLE1BQU0sT0FBTyxDQUFDLG9CQUFvQixDQUFDO1lBQzlDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxFQUFFO1lBQzFCLFVBQVUsRUFBRSxTQUFTO1NBQ3RCLENBQUMsQ0FBQTtRQUNGLE1BQU0sQ0FBQyxJQUFJLENBQ1Qsa0JBQWtCLEtBQUssQ0FBQyxFQUFFLGVBQWUsU0FBUyxXQUFXLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FDdkUsQ0FBQTtJQUNILENBQUM7QUFDSCxDQUFDIn0=